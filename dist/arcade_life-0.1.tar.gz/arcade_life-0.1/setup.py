from setuptools import setup

setup(name='arcade_life',
	  version='0.1',
	  description='An interactive implementaion of of Game Of Life',
	  url='https://github.com/PaulNicolasHunter/Game-Of-Life-Interactive-Application',
	  author='Vivek Choudhary (PaulNicoalsHunter)',
	  author_email='choudhary.vivek98@gmail.com',
	  license='MIT')
